from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtGui import QIcon

def warningBox(windowTitle: str, message: str, path: str):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Warning)
    msg.setWindowIcon(QIcon(path))
    msg.setText(message)
    msg.setWindowTitle(windowTitle)
    msg.exec()