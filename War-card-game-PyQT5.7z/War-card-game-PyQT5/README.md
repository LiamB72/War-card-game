# War card game
 It's the classic war card game where two players have at first a deck of 26 cards from a 52-card game. Each player takes a card from their deck  where the opponent can't see which card is taken, then both player places their card to see which of the two has the highest value, for the winner to take both cards back. The goal is to get all 52 cards. However, the twist is that it's made in Python, using pyqt6 for the GUI and the socket module to connect and transfer data between players. And as you may have understood, you are meant to play with at least two computers! Thus maximum and minimum of 2 players are required to play that game!

# About the MIT License.
 Its main purpose is only allowing others to copy and do whatever with that code. I do not intend to sell or use that piece of software for commercial usage. Although, you may copy and change the code enough to do what you want with it.

# Game Author
This kid's game is designed by Greg Costikyan. See https://en.wikipedia.org/wiki/War_(card_game) for more reference.
